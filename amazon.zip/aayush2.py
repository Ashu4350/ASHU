import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv(r"C:\Users\SAITM\Downloads\amazon_prime_users.csv", encoding="latin1")


print(df.describe())


plt.hist(df["Name"], histtype='bar', ec='black')
plt.xlabel('Payment Information')
plt.ylabel('Username')
plt.title('Userbase')
plt.show()