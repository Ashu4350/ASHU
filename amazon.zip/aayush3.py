import seaborn as sns
import pandas as pd
from matplotlib import pyplot as plt

df = pd.read_csv(r"C:\Users\SAITM\Downloads\amazon_prime_users.csv", encoding='latin1')

sns.boxplot(data=df)

plt.xlabel('Username')
plt.ylabel('Membership End Date')
plt.title('Members')

plt.show()