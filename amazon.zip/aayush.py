import pandas as pd
import matplotlib.pyplot as plt

df1 = pd.read_csv(r"C:\Users\SAITM\Downloads\amazon_prime_users.csv", encoding= "latin1")

print(df1.describe())
bin_edges = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150]

plt.hist(df1["Username"], histtype='bar', ec='black', bins=bin_edges)
g = plt.xlabel('Name')
g = plt.ylabel('Gender')
g = plt.title('Subscription Plan')
plt.show()